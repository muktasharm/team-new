const mongoose=require('mongoose');

// user schema
const userSchema=new mongoose.Schema({
    email:String,
    password:String,
    userProfile:String,
    personName:String,
    dob:String,
    phone:Number,
    wallet:Number,
    coins:Number,
    userStatus:{
        type:Boolean,
        default:false,

    },
    userActStatus:{
        type:Boolean,
        default:true
    }

},{timestamps:true});

//contactus schema
const contactusSchema=new mongoose.Schema({
    clientName:String,
    phone:Number,
    email:String,
    whatsappNumber:Number

});

const aboutusSchema=new mongoose.Schema({
    title:String,
    text:String

});

//models
const userModel=mongoose.model('user',userSchema);
const contactusModel=mongoose.model('contactus',contactusSchema);
const aboutusModel=mongoose.model('aboutus',aboutusSchema);

module.exports={
    userModel,
    contactusModel,
    aboutusModel,

}