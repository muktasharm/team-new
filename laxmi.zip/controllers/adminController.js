
const {
    userModel,
}=require("./../models/schemaModels");
const bcrypt=require('bcrypt');

//user register
const userRegister=async(req,res)=>{
    try{
        const {email,password,personName,phone,dob}=req.body;
        if(!email || !password){
            return res.status(404).json({result:false,message:"required fields are email,password,personName,phone,dob"})
        }
        const data=await userModel.findOne({email});
        if(data){
            return res.status(404).json({result:false,message:"Email is already exists"})
        }
        //hashing password
        const hashPassword=await bcrypt.hash(password,10);
        const  insertUser=new userModel({email,password:hashPassword,personName,phone,dob})
         const user=await insertUser.save();
         res.status(200).json({result:true,message:"User registered successfullly",data:user})
    }catch(err){
        res.status(500).json({result:false,message:err.message});
    }

};


module.exports={
    userRegister,
}