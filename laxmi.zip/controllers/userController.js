//import models
const {
    userModel,
    contactusModel,
    aboutusModel,

}=require("./../models/schemaModels.js");


require("dotenv").config()
const jwt=require('jsonwebtoken');
const bcrypt=require('bcrypt');


const securect_key=process.env.securect_key;

// user login api
const userLogin=async(req,res)=>{
    try{
        const {email,password}=req.body;
        if(!email || !password){
            return res.status(404).json({result:false,message:"required fields are email and password"})
        }
        const user=await userModel.findOne({email});
        if(!user){
            return res.status(404).json({result:false,message:"Invalid email address"})
        }
        const matchPassword=await bcrypt.compare(password,user.password);
        if(!matchPassword){
            return res.status(404).json({result:false,message:"Please enter correct password"})
        }
        //generate token
        const token=jwt.sign({user},securect_key,{expiresIn:'365d'});
        res.status(200).json({result:false,message:"You are logined successfully",data:user,token})
        
    }catch(err){
        res.status(500).json({result:false,message:err.message})
    }
};

const userGetData=async(req,res)=>{
    try{
        const {userId}=req.body;
        if(!userId){
            return res.status(404).json({result:false,message:"userId is required"})
        }
        const user=await userModel.findById({_id:userId});
        if(!user){
            return res.status(404).json({result:false,message:"Invalid userId"})
        }
        res.status(200).json({result:true,message:"User data is..",data:user})

        
    }catch(err){
        res.status(500).json({result:false,message:err.message})
    }

};


const updateUserProfile=async(req,res)=>{
    try{
        const {userId,dob,phone,personName,email}=req.body;
        if(!userId){
            return res.status(404).json({result:false,message:"Required fields are userId and optionals are personName,userProfile,dob,email,phone"})
        }
        const updatedObject={
            dob,
            personName,
            email,
            phone
        }
        if(req.file){
            updatedObject.userProfile=req.file.filename;
        }
        await userModel.findByIdAndUpdate({_id:userId},updatedObject,{new:true});
        res.status(200).json({result:true,message:"User Profile updated successfully"})

        
    }catch(err){
        res.status(500).json({result:false,message:err.message})
    }

};



const contactusList=async(req,res)=>{
    try{

        const data=await contactusModel.findOne({});
        if(!data){
            return res.status(404).json ({result:false,message:"Record not found"})
        }
        res.status(200).json({result:true,message:"Contactus list is",data:data})

        
    }catch(err){
        res.status(500).json({result:false,message:err.message})
    }

};

const aboutusList=async(req,res)=>{
    try{
        const data=await aboutusModel.findOne({});
        if(!data){
            return res.status(404).json ({result:false,message:"Record not found"})
        }
        res.status(200).json({result:true,message:"Contactus list is",data:data})


        
    }catch(err){
        res.status(500).json({result:false,message:err.message})
    }

};



module.exports={
    userLogin,
    userGetData,
    updateUserProfile,
    contactusList,
    aboutusList,

};