const express=require('express');
const router=express();
const adminController=require("./../controllers/adminController");
const multer=require('multer');

//use multer
const storage=multer.diskStorage({
    destination:"uploads",
    filename:(req,file,cb)=>{
        cb(null,file.originalname)

    },

});

const upload=multer({
    storage:storage,
    fileFilter:((req,file,callback)=>{
        if(file.mimetype=='image/png' ||
            file.mimetype == "image/jpg" ||
                 file.mimetype == "image/jpeg"||
                 file.mimetype == "text/csv"  ||
				 file.mimetype == "application/pdf" ||
				 file.mimetype == "audio/mpeg" || 
				 file.mimetype == "video/mp4" 

        ){
            callback(null,true)
        }else{
            console.log("Only supported formates are pdf,mp4,png,jpeg,jpg,mpeg,csv")
            callback(null,false)
        }

    }),
    limits:{
        fileSize:100000000//1000000 bytes=1mb
    }

});

// set url
router.post("/userRegister",upload.single('userProfile'),adminController.userRegister);

module.exports=router;