//import dependancies
const express=require("express");
const app= express();
require('dotenv').config();
const userRouter=require("./routers/userRouter");
const adminRouter=require("./routers/adminRouter");

//declear middleware
app.use(express.json());
app.use("/laxmi/api",userRouter);
app.use("/laxmi/admin",adminRouter);




//module exprots
module.exports=app;